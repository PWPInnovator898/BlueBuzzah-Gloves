# This file is part of the BlueBuzzah Gloves project
# Copyright (c) 2025 BlueBuzzah Partners
# Licensed under the MIT License
#
# This file makes use of libraries and modules developed by Adafruit Industries,
# which are licensed separately under the MIT License and available at:
# https://github.com/adafruit/Adafruit_CircuitPython_Bundle
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
#
# For full licensing and attribution details, see LICENSES/MIT.txt and ATTRIBUTION.md

import time
# import supervisor
from neopixel_manager import pixels
from adafruit_ble import BLERadio
from adafruit_ble.services.nordic import UARTService
from adafruit_ble.advertising.standard import ProvideServicesAdvertisement
from main_program_VCR import run_vcr

ble = BLERadio()
uart_service = UARTService()
advertisement = ProvideServicesAdvertisement(uart_service)
advertisement.complete_name = "VL"

def enter_low_power_mode():
    print("Entering lowest power mode...")
    pixels.fill((0, 0, 0))
    ble.stop_scan()
    ble.stop_advertising()
    # ble.disconnect()
    time.sleep(0.5)
    # supervisor.runtime.sleep_forever()

print("[VL] Setting up BLE advertisement with UARTService...")
ble.start_advertising(advertisement, interval=0.5)
print("[VL] Advertising as VL...")

start_time = time.monotonic()
slave_found = False

while time.monotonic() - start_time < 15:
    if ble.connected:
        print("[VL]Slave connected during 15s window!")
        connection = ble.connections[0]
        connection.interval = 0.0075
        connection.latency = 0
        connection.timeout = 0.1
        print("[VL] BLE parameters opt: Interval=7.5ms, Latency=0, Timeout=100ms")
        slave_found = True
        break

if not slave_found:
    print("[VL] No Slave found in 15s! Restart required.")
    pixels.fill((255, 0, 0))
    while True:
        pass

print("[VL] Slave connected! Waiting for READY signal...")

# NEW: Wait for Slave to send READY signal before sending SYNC
ready_received = False
start_wait = time.monotonic()

while time.monotonic() - start_wait < 8:
    message = uart_service.readline()
    if message:
        message = message.decode("utf-8").strip()
        print("[VL] Debug: Received: {}".format(message))
        if message == "READY":
            ready_received = True
            break

if not ready_received:
    print("[VL] No READY received! Restart required.")
    pixels.fill((255, 0, 0))
    while True:
        pass

# NEW: Retry sending SYNC until ACK is received
timestamp = int(time.monotonic() * 1000)
sync_message = "FIRST_SYNC:{}\n".format(timestamp)  # Mark first sync

ack_received = False
for attempt in range(3):
    print(f"[VL] Sending SYNC message (Attempt {attempt+1}): {sync_message}")
    sync_send_time = int(time.monotonic() * 1000)
    print(f"[VL] SYNC sent at {sync_send_time} ms")
    uart_service.write(sync_message.encode())
    time.sleep(0.5)

    message = uart_service.readline()
    if message:
        message = message.decode("utf-8").strip()
        print("[VL] Debug: Received: {}".format(message))
        if message == "ACK":
            ack_received = True
            break

if not ack_received:
    print("[VL] No ACK received! Restart required.")
    pixels.fill((255, 0, 0))
    while True:
        pass

print("[VL] Sending VCR_START...")
uart_service.write("VCR_START\n".encode())

print("[VL] Running main VCR program...")
run_vcr(uart_service)
enter_low_power_mode()
