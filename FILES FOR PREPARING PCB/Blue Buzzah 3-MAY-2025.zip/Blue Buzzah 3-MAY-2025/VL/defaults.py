# This file is part of the BlueBuzzah Gloves project
# Copyright (c) 2025 BlueBuzzah Partners
# Licensed under the MIT License
#
# This file makes use of libraries and modules developed by Adafruit Industries,
# which are licensed separately under the MIT License and available at:
# https://github.com/adafruit/Adafruit_CircuitPython_Bundle
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
#
# For full licensing and attribution details, see LICENSES/MIT.txt and ATTRIBUTION.md

# Apr 30, 2025 at 07:05
# import math
import time
ACTUATOR_TYPE = "LRA"
ACTUATOR_VOLTAGE = 2.47485
ACTUATOR_FREQUENCY = 250
RANDOM_FREQ = False
ACTUATOR_FREQL = 250
ACTUATOR_FREQNOM = ACTUATOR_FREQUENCY
ACTUATOR_FREQH = 250
AMPLITUDE_MIN = 70
AMPLITUDE_MAX = 127
TIME_SESSION = 60
TIME_ON = 0.1
TIME_OFF = 0.0666666667 
TIME_RELAX = 4 * (TIME_ON + TIME_OFF)
JITTER = 10.0
TIME_JITTER = (TIME_ON + TIME_OFF) * (JITTER / 100) / 2
TIME_END = time.time() + 60 * TIME_SESSION
# VCR period = 0.1666666667
# VCR frequency = 5.9999999988
PATTERN_TYPE = "RVS"
MIRROR = True
SYNC_LED = True