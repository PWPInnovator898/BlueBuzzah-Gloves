# This file is part of the BlueBuzzah Gloves project
# Copyright (c) 2025 BlueBuzzah Partners
# Licensed under the MIT License
#
# This file makes use of libraries and modules developed by Adafruit Industries,
# which are licensed separately under the MIT License and available at:
# https://github.com/adafruit/Adafruit_CircuitPython_Bundle
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
#
# For full licensing and attribution details, see LICENSES/MIT.txt and ATTRIBUTION.md
import defaults
import time
import analogio
import board
import neopixel
import adafruit_ble
import supervisor
import storage
from adafruit_ble.services.nordic import UARTService
from adafruit_ble.advertising.standard import ProvideServicesAdvertisement

pixel = neopixel.NeoPixel(board.NEOPIXEL, 1, brightness=0.2)
pixel.fill((0, 0, 0))

ble = adafruit_ble.BLERadio()
ble.name = "VR"
uart_service = UARTService()
advertisement = ProvideServicesAdvertisement(uart_service)
advertisement.complete_name = ble.name
uart_service.timeout = 0.1

# Assign role tag for clarity
if ble.name == "VL":
    ROLE_TAG = "[VL]"
elif ble.name == "VR":
    ROLE_TAG = "[VR]"
else:
    ROLE_TAG = "[??]"

def blink_neopixel(color, blinks, delay):
    for _ in range(blinks):
        pixel.fill(color)
        time.sleep(delay)
        pixel.fill((0, 0, 0))
        time.sleep(delay)

def pulse_purple(duration_sec):
    end = time.monotonic() + duration_sec
    while time.monotonic() < end:
        for i in range(0, 256, 10):
            pixel.fill((i // 2, 0, i))
            time.sleep(0.01)
        for i in range(255, -1, -10):
            pixel.fill((i // 2, 0, i))
            time.sleep(0.01)
    pixel.fill((0, 0, 0))

def check_glove_status():
    try:
        vbat_voltage = analogio.AnalogIn(board.VOLTAGE_MONITOR)
        battery_voltage = (vbat_voltage.value * 3.3) / 65536 * 2
        vbat_voltage.deinit()
        uart_service.write(f"{ROLE_TAG}Battery: {battery_voltage:.2f}V\n".encode())
        if battery_voltage > 3.7:
            color = (0, 255, 0)
        elif battery_voltage > 3.4:
            color = (255, 150, 0)
        else:
            color = (255, 0, 0)
        blink_neopixel(color, 2, 0.5)
    except Exception as e:
        print(f"{ROLE_TAG}[ERROR] Battery check:", e)

def view_defaults_file():
    try:
        uart_service.write(f"{ROLE_TAG}=== START OF DEFAULTS.PY ===\n".encode())
        with open("/defaults.py", "r") as f:
            for i, line in enumerate(f, start=1):
                uart_service.write("[{:02d}] {}".format(i, line).encode())
                time.sleep(0.05)
        uart_service.write(f"{ROLE_TAG}=== END OF DEFAULTS.PY ===\n".encode())
    except Exception as e:
        print(f"{ROLE_TAG}[ERROR] Viewing defaults:", e)

def en_rw_filesystem():
    if not supervisor.runtime.usb_connected:
        storage.remount("/", readonly=False)

def try_write_defaults(src_name):
    if supervisor.runtime.usb_connected:
        warning = f"{ROLE_TAG}[ERROR] USB is connected; cannot modify filesystem.\n"
        print(warning)
        uart_service.write(warning.encode())
        return False
    try:
        storage.remount("/", readonly=False)
        with open(src_name, "r") as src, open("defaults.py", "w") as dst:
            dst.write(src.read())
        return True
    except Exception as e:
        print(f"{ROLE_TAG}[ERROR] Writing defaults:", e)
        return False

# Start BLE advertising
ble.start_advertising(advertisement, interval=0.1)
startup_time = time.monotonic()
command_received = False

# 12-second default timeout with purple pulsing LED
while time.monotonic() - startup_time < defaults.STARTUP_WINDOW:
    pulse_purple(0.5)
    if ble.connected and uart_service.in_waiting:
        raw_msg = uart_service.readline()
        if raw_msg:
            msg = raw_msg.strip().decode()
            if not msg:
                continue
            msg = msg[0]

            if msg not in ["f", "c", "g", "v", "r", "1", "2", "3", "4"]:
                print(f"[WARNING]  Unknown input ignored: '{msg}'")
                continue

            print(f"{ROLE_TAG}Received: '{msg}'")

            if msg == "1":
                if try_write_defaults("defaults_RegVCR.py"):
                    uart_service.write(b"Loaded defaults_RegVCR.py\n")
                    blink_neopixel((0, 255, 255), 3, 0.25)
                command_received = True
                break

            elif msg == "2":
                if try_write_defaults("defaults_NoisyVCR.py"):
                    uart_service.write(b"Loaded defaults_NoisyVCR.py\n")
                    blink_neopixel((0, 255, 255), 3, 0.25)
                command_received = True
                break

            elif msg == "3":
                if try_write_defaults("defaults_HybridVCR.py"):
                    uart_service.write(b"Loaded defaults_HybridVCR.py\n")
                    blink_neopixel((0, 255, 255), 3, 0.25)
                command_received = True
                break

            elif msg == "4":
                if try_write_defaults("defaults_CustomVCR.py"):
                    uart_service.write(b"Loaded defaults_Custom.VCR.py\n")
                    blink_neopixel((0, 255, 255), 3, 0.25)
                command_received = True
                break

            elif msg == "v":
                uart_service.write(f"{ROLE_TAG}[INFO] Viewing Defaults".encode())
                time.sleep(0.05)
                view_defaults_file()
                command_received = True
                break

            elif msg == "g":
                uart_service.write(f"{ROLE_TAG}[INFO] Battery Check Start\n".encode())
                time.sleep(0.05)
                check_glove_status()
                command_received = True
                break

            elif msg == "c":
                uart_service.write(f"{ROLE_TAG}[INFO] Calibration Start\n".encode())
                time.sleep(0.05)
                blink_neopixel((255, 255, 0), 5, 0.25)
                command_received = True
                break

            elif msg == "f":
                uart_service.write(
                    f"{ROLE_TAG}[INFO] FileGlider Mode Enabled. \
                                    Open FileGlider app".encode()
                )
                time.sleep(0.05)
                en_rw_filesystem()
                blink_neopixel((255, 255, 255), 5, 0.5)
                command_received = True
                break

            elif msg == "r":
                uart_service.write(
                    f"{ROLE_TAG}[INFO] \
                                    Restarting to Menu Controller".encode()
                )
                time.sleep(0.05)
                blink_neopixel((0, 255, 0), 5, 0.25)
                print("[SYSTEM] Rebooting into BLE Menu Mode")
                time.sleep(0.5)
                supervisor.set_next_code_file("menu_controller.py")
                supervisor.reload()

if not command_received:
    print(f"{ROLE_TAG}Timeout. Launching code_slave.py...")
    supervisor.set_next_code_file("code_slave.py")
    supervisor.reload()

# Infinite loop
while True:
    pixel.fill((64, 0, 128))
    time.sleep(0.05)
    if ble.connected and uart_service.in_waiting:
        raw_msg = uart_service.readline()
        if raw_msg:
            msg = raw_msg.strip().decode()
            if not msg:
                continue
            msg = msg[0]
            print(f"{ROLE_TAG}Received (loop): '{msg}'")

            if msg == "1":
                if try_write_defaults("defaults_RegVCR.py"):
                    uart_service.write(b"Loaded defaults_RegVCR.py\n")
                    blink_neopixel((0, 255, 255), 3, 0.25)

            elif msg == "2":
                if try_write_defaults("defaults_NoisyVCR.py"):
                    uart_service.write(b"Loaded defaults_NoisyVCR.py\n")
                    blink_neopixel((0, 255, 255), 3, 0.25)

            elif msg == "3":
                if try_write_defaults("defaults_HybridVCR.py"):
                    uart_service.write(b"Loaded defaults_HybridVCR.py\n")
                    blink_neopixel((0, 255, 255), 3, 0.25)

            elif msg == "4":
                if try_write_defaults("defaults_CustomVCR.py"):
                    uart_service.write(b"Loaded defaults_CustomVCR.py\n")
                    blink_neopixel((0, 255, 255), 3, 0.25)

            elif msg == "v":
                uart_service.write(f"{ROLE_TAG}[INFO] Viewing Defaults".encode())
                time.sleep(0.05)
                view_defaults_file()

            elif msg == "g":
                uart_service.write(f"{ROLE_TAG}[INFO] Battery Check Start\n".encode())
                time.sleep(0.05)
                check_glove_status()

            elif msg == "c":
                uart_service.write(f"{ROLE_TAG}[INFO] Calibration Start\n".encode())
                time.sleep(0.05)
                blink_neopixel((255, 255, 0), 5, 0.25)

            elif msg == "r":
                uart_service.write(
                    f"{ROLE_TAG}[INFO] \
                                    Restarting to Menu Controller".encode()
                )
                time.sleep(0.05)
                blink_neopixel((255, 0, 0), 5, 0.25)
                print("[SYSTEM] Rebooting into BLE Menu Mode...")
                time.sleep(0.5)
                supervisor.set_next_code_file("menu_controller.py")
                supervisor.reload()

            if msg == "f":
                uart_service.write(
                    f"{ROLE_TAG}[INFO] FileGlider \
                                    Mode Enabled. Open FileGlider app".encode()
                )
                time.sleep(0.05)
                en_rw_filesystem()
                blink_neopixel((255, 255, 255), 5, 0.5)

