# This file is part of the BlueBuzzah Gloves project
# Copyright (c) 2025 BlueBuzzah Partners
# Licensed under the MIT License
#
# This file makes use of libraries and modules developed by Adafruit Industries,
# which are licensed separately under the MIT License and available at:
# https://github.com/adafruit/Adafruit_CircuitPython_Bundle, and the Buzzah project at:
# https://github.com/kriswilk/buzzah
# For licensing and attribution details, see LICENSES/MIT.txt and ATTRIBUTION.md at:
# https://github.com/PWPInnovator898/BlueBuzzah-Gloves
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Declare global time adjustment variable before using it
timebase_adjustment = 0  # Default to zero, updated on each sync

def run_vcr(uart_service):
    print("Running main BUZZ program...")

    # Get free-run mode default VCR settings
    import defaults

    import board
    import gc

    # from adafruit_ble import BLERadio
    # from adafruit_ble.advertising.standard import ProvideServicesAdvertisement
    # from adafruit_ble.services.nordic import UARTService

    import adafruit_itertools
    from adafruit_itertools import permutations
    import adafruit_drv2605
    import adafruit_tca9548a
    # import microcontroller

    import random
    import time
    from analogio import AnalogIn
    from neopixel_manager import pixels

    # import sys

    # import storage
    # import adafruit_ble
    # from adafruit_ble.services.standard import CurrentTimeService
    # from adafruit_ble.advertising.standard import SolicitServicesAdvertisement
    # import supervisor

    # Set up to monitor battery voltage
    vbat_voltage = AnalogIn(board.VOLTAGE_MONITOR)

    def get_voltage(pin):
        return (pin.value * 3.3) / 65536 * 2

    # Show battery status before therapy
    battery_voltage = get_voltage(vbat_voltage)
    print("VBat voltage: {:.2f}".format(battery_voltage))

    if (battery_voltage) >= 3.6:
        print("Battery volt > 3.6v --> battery good", "\n")
        # Set neopixel GREEN for 3s
        pixels.fill((0, 255, 0))
        pixels.show()
        time.sleep(5)

    if ((battery_voltage) > 3.3 and (battery_voltage) < 3.6):
        print("Battery volt < 3.6v --> recharge soon", "\n")
        # Set neopixel ORANGE
        pixels.fill((255, 165, 0))
        pixels.show()
        time.sleep(5)

    if (battery_voltage) <= 3.3:
        print("Battery volt < 3.3v --> CRITICAL RECHARGE NEEDED", "\n")
        # Set neopixel RED
        pixels.fill((255, 0, 0))
        pixels.show()
        time.sleep(10)

    CUSTOMIZATIONS = False

    # Stop_LED = input("LEDs ok?")

    """
    ACTUATOR SPECIFICATIONS: These MUST be set to match the specifications of the
    actuator that you are using.
    """

    if CUSTOMIZATIONS:
        print(defaults.ACTUATOR_TYPE)
        print(defaults.ACTUATOR_VOLTAGE)
        print(defaults.ACTUATOR_FREQUENCY)
        print(defaults.RANDOM_FREQ)
        print(defaults.ACTUATOR_FREQL)
        print(defaults.ACTUATOR_FREQNOM)
        print(defaults.ACTUATOR_FREQH)

        # COORDINATED RESET PARAMETERS: These are based on the published research

        # Vibration amplitude range, in %
        print(defaults.AMPLITUDE_MIN)
        print(defaults.AMPLITUDE_MAX)

        # Duration of each vibration and subsequent pause, each in seconds
        print(defaults.TIME_ON)
        print(defaults.TIME_OFF)

        # Duration of the relaxation period between sets of vibrations, in seconds
        print(defaults.TIME_RELAX)

        # Jitter, in %
        print(defaults.JITTER)

        # Mirror left / right hand vibration patterns
        print(defaults.MIRROR)

        # Duration of the therapy session, in minutes
        print(defaults.TIME_SESSION)

        # Check all values - comment out later
        # CHECKT = input("pause?")

    PATTERNS_LEFT = list(adafruit_itertools.permutations(range(0, 4)))
    # PATTERNS_RIGHT = list(adafruit_itertools.permutations(range(0, 4)))
    # print(PATTERNS_LEFT)
    # print(PATTERNS_RIGHT)
    # CHECKT = input("patterns?")

    L_RNDP = list(permutations(range(0, 4)))     # 24 patterns for LEFT
    R_RNDP = list(permutations(range(4, 8)))     # 24 patterns for RIGHT

    # Receive shared seed from VL over BLE and apply it
    SHARED_SEED = 123456  # Default seed if jitter is off (matches VL)
    if defaults.JITTER != 0:
        while True:
            data = uart_service.readline()
            if not data:
                continue
            try:
                decoded = data.decode().strip()
                if decoded.startswith("SEED:"):
                    SHARED_SEED = int(decoded.split(":")[1])
                    print("[VR] Received shared seed:", SHARED_SEED)
                    random.seed(SHARED_SEED)
                    print("[VR] Applied shared seed due to non-zero jitter")
                    break
            except Exception as e:
                print("[VR] Error decoding shared seed:", e)

    def random_sequence():
        if defaults.MIRROR:
            # print("Mirror mode pattern sequence...")
            pattern_left = random.choice(PATTERNS_LEFT)
            pattern_right = pattern_left
            # print(f"{pattern_left} , LEFT Mirror")
            # print(f"{pattern_right} , RIGHT Mirror")
        else:
            # print("Non-mirror mode pattern sequence...")
            # pattern_left = random.choice(PATTERNS_LEFT)
            # pattern_right = random.choice(PATTERNS_RIGHT)
            pattern_left = random.\
                choice(list(adafruit_itertools.permutations(range(0, 4))))
            pattern_right = random.choice(R_RNDP)
            # print(f"{pattern_left}, LEFT Random")
            # print(f"{pattern_right}, RIGHT Random")
        return zip(pattern_left, pattern_right)

    # CHECKT = input("patterns new?")
    # print(CHECKT)

    def rndp_sequence():
        pattern_left_rndp = random.choice(L_RNDP)
        # print(pattern_left_rndp)
        if defaults.MIRROR:
            pattern_right_rndp = [x - 4 for x in pattern_left_rndp]
        else:
            pattern_right_rndp = random.choice(R_RNDP)
        # print(pattern_right_rndp)
        return zip(pattern_left_rndp, pattern_right_rndp)

    def fingers_on(fingers):
        for finger in fingers:
            actual_finger = finger[0] if isinstance(finger, tuple) else finger
            idx = actual_finger - 4 if not defaults.MIRROR else actual_finger
            if 0 <= idx < len(drivers) and drivers[idx]:
                drivers[idx].realtime_value = random.randint(
                    defaults.AMPLITUDE_MIN, defaults.AMPLITUDE_MAX
                )

    def fingers_off(fingers):
        for finger in fingers:
            actual_finger = finger[0] if isinstance(finger, tuple) else finger
            idx = actual_finger - 4 if not defaults.MIRROR else actual_finger
            if 0 <= idx < len(drivers) and drivers[idx]:
                drivers[idx].realtime_value = 0

    def buzz_sequence(sequence):
        for fingers in sequence:
            fingers_on(fingers)
            time.sleep(defaults.TIME_ON)
            fingers_off(fingers)
            time.sleep(
                defaults.TIME_OFF
                + random.uniform(-defaults.TIME_JITTER, defaults.TIME_JITTER)
            )

    # Start of main program flow
    # BLE radio setup
    # ble = BLERadio()
    # uart_service = UARTService()
    # advertisement = ProvideServicesAdvertisement(uart_service)

    # Advertise when not connected
    # ble.start_advertising(advertisement)

    start_config_time = time.time()  # keep track of time in setup
    # print(start_config_time)

    # Flash neopixel blue at begin of power up
    for i in range(5):
        pixels.fill((0, 0, 255))
        pixels.show()
        time.sleep(0.05)
        pixels.fill((0, 0, 0))
        pixels.show()
        time.sleep(0.05)

    # new stop
    # ble.stop_advertising

    print("VCR starting up... wait 1s 'til power supply is stable ...")

    # set up i2c from nRF52840 to i2c mux to to haptic drivers
    i2c = board.I2C()
    mux = adafruit_tca9548a.PCA9546A(i2c)

    # Scan for I2C addresses... and unlock master I2C bus
    while not i2c.try_lock():
        pass
    try:
        print(
            "I2C Master I2C addresses found:",
            [hex(device_address) for device_address in i2c.scan()],
        )
        time.sleep(0.1)
    finally:
        i2c.unlock()

    # Scan for slave I2C addresses... and unlock each slave I2C bus
    for channel in range(4):
        if mux[channel].try_lock():
            print("Slave i2c Channel {}:".format(channel), end="")
            addresses = mux[channel].scan()
            print([hex(address) for address in addresses])
            mux[channel].unlock()

    print("Begin haptic driver config ...", "\n")

    # print("\nBEGIN initial config driver loop")

    drivers = []
    for port in mux:
        # print("APPEND a haptic driver to each i2c port", port)
        try:
            drivers.append(adafruit_drv2605.DRV2605(port))
        except ValueError:
            drivers.append(False)

    # print("BEGIN setting haptic driver config registers")
    for driver in drivers:
        # print(driver)
        if driver:
            # set actuator type
            if defaults.ACTUATOR_TYPE == "LRA":
                driver.use_LRM()
                # print("set LRA mode")
            else:
                driver.use_ERM()

            # set open-loop mode (both ERM & LRA)
            # print("set open-loop mode")
            control3 = driver._read_u8(0x1D)
            driver._write_u8(0x1D, control3 | 0x21)

            # set peak voltage
            # print("set peak voltage")
            driver._write_u8(0x17, int(defaults.ACTUATOR_VOLTAGE / 0.02122))

            # set driving frequency
            # print("set driving frequency")
            driver._write_u8(0x20, int(1 / (defaults.ACTUATOR_FREQUENCY * 0.00009849)))
            # print("main", defaults.ACTUATOR_FREQUENCY)

            # set initial output amplitude and activate RTP mode
            driver.realtime_value = 0
            # print("activate RTP mode")
            driver.mode = adafruit_drv2605.MODE_REALTIME
            # print(drivers)

    # vbat_counter = 0  # optional battery monitor loop counter to flash every # cycles
    buzz_cycle_count = 0  # buzz cycle counter

    end_config_time = time.time()
    elapsed_config_time = end_config_time - start_config_time
    # print("config_time = ", elapsed_config_time)
    # input("pause to show config time (seconds) \n")
    # sync_start = input("Begin sync")

    # Main loop
    while time.time() < defaults.TIME_END + elapsed_config_time:
        if defaults.RANDOM_FREQ:
            drivers = []
            for port in mux:
                try:
                    drivers.append(adafruit_drv2605.DRV2605(port))
                except ValueError:
                    drivers.append(False)

            for driver in drivers:
                if driver:
                    # set actuator type
                    if defaults.ACTUATOR_TYPE == "LRA":
                        driver.use_LRM()
                    else:
                        driver.use_ERM()

                    # set open-loop mode (both ERM & LRA)
                    control3 = driver._read_u8(0x1D)
                    driver._write_u8(0x1D, control3 | 0x21)

                    # set peak voltage
                    driver._write_u8(0x17, int(defaults.ACTUATOR_VOLTAGE / 0.02122))

                    # set driving frequency
                    # FREQ_OPTION = (
                    # defaults.ACTUATOR_FREQL,
                    # defaults.ACTUATOR_FREQNOM,
                    # defaults.ACTUATOR_FREQH,
                    # )
                    ACTUATOR_FREQUENCY = random.randrange(
                        defaults.ACTUATOR_FREQL, defaults.ACTUATOR_FREQH, 5)
                    driver._write_u8(0x20, int(1 / (ACTUATOR_FREQUENCY * 0.00009849)))
                    # print("innerloop", ACTUATOR_FREQUENCY)

                    # set initial output amplitude and activate RTP mode
                    driver.realtime_value = 0
                    driver.mode = adafruit_drv2605.MODE_REALTIME
                    # print(driver)

        buzz_cycle_count += 1
        # print(f"Buzz cycle count: {buzz_cycle_count}")

        if buzz_cycle_count == 1:  # indicate start INITIAL buzz cycle w/ white led
            # print("Starting **FIRST** buzz macrocycle w/ white LED ...")
            pixels.fill((255, 255, 255))
            pixels.show()
            time.sleep(0.1)
            pixels.fill((0, 0, 0))
            pixels.show()

        # macrocell_start = int(time.monotonic() * 1000)
        # print("[VR] Buzz Macrocycle Start @", macrocell_start)

        # Debug Mode Toggle
        DEBUG_MODE = True  # Set to True to enable logging
        # FIXED_OFFSET = -57  # OLD -- Add a fixed offset to align with Master

        # Buffered Log (stored in memory, printed only at the end)
        debug_log = []

        # Periodic Sync logic for Slave (VR)
        if buzz_cycle_count % 1 == 0 and uart_service:
            timeout_start = time.monotonic()
            sync_adj_timestamp = None

            while (time.monotonic() - timeout_start) < 2.0:
                if uart_service.in_waiting:
                    response = uart_service.readline().decode().strip()

                    if response.startswith("SYNC_ADJ:"):
                        sync_adj_timestamp = int(response.split(":")[1])
                        received_timestamp = int(time.monotonic() * 1000)

                        # Apply correction using moving average for smooth sync
                        global timebase_adjustment
                        ALPHA = 1.0  # Weight for smoothing correction
                        new_offset = sync_adj_timestamp - received_timestamp
                        timebase_adjustment = (
                            (ALPHA * new_offset) +
                            ((1 - ALPHA) * timebase_adjustment))

                        if DEBUG_MODE:
                            debug_log.append(
                                "[VR] Received SYNC_ADJ @ \
                                    {} ms".format(received_timestamp))
                            debug_log.append(
                                "[VR] Master Sent: \
                                    {} ms".format(sync_adj_timestamp))
                            debug_log.append(
                                "[VR] Smoothed Offset Applied: \
                                    {:.2f} ms".format(timebase_adjustment))
                        break

            # Send ACK to Master
            uart_service.write("ACK_SYNC_ADJ\n")

            # Wait for SYNC_ADJ_START to begin execution
            timeout_start = time.monotonic()
            while (time.monotonic() - timeout_start) < 2.0:
                if uart_service.in_waiting:
                    response = uart_service.readline().decode().strip()
                    if response == "SYNC_ADJ_START":
                        sync_adj_start_received = int(time.monotonic() * 1000)
                        delay = sync_adj_start_received - sync_adj_timestamp

                        # if DEBUG_MODE:
                        debug_log.append("[VR]SYNC_ADJ_START (Dly:{} ms)".format(delay))
                        break

            # Adjust Slave start time using corrected timebase
            adjusted_start_time = int(time.monotonic() * 1000) + timebase_adjustment
            if DEBUG_MODE:
                debug_log.append("[VR] Adjusted \
                    Start Time: {} ms".format(adjusted_start_time))

            # Only print logs once per 5 cycles (avoids excessive I/O delay)
            if DEBUG_MODE and (buzz_cycle_count % 5 == 0):  # Print every 5 cycles
                for log in debug_log:
                    print(log)
                debug_log.clear()  # Reset the buffer after printing

        # Function to get adjusted time for future sync events
        def get_adjusted_time():
            global timebase_adjustment
            return int(time.monotonic() * 1000) + timebase_adjustment

        # Proceed with next cycle

        if defaults.PATTERN_TYPE == "RNDP":
            buzz_sequence(rndp_sequence())
            buzz_sequence(rndp_sequence())
            buzz_sequence(rndp_sequence())
            time.sleep(defaults.TIME_RELAX)
            time.sleep(defaults.TIME_RELAX)
        else:
            buzz_sequence(random_sequence())
            buzz_sequence(random_sequence())
            buzz_sequence(random_sequence())
            time.sleep(defaults.TIME_RELAX)
            time.sleep(defaults.TIME_RELAX)

        gc.collect()
        # Optional: debug free memory
        # print("[VR] Free RAM:", gc.mem_free())

        # macrocell_end = int(time.monotonic() * 1000)
        # print("[VR] Buzz macrocycle END @", macrocell_end)
        # print("[VR] Buzz macrocycle duration=", macrocell_end - macrocell_start)
        # print("Completing Buzz Macrocycle in main_program_VCR...")

        # Optional SYNC_LED flash for h/w validation at end of 3:2 buzzcycle
        if (defaults.SYNC_LED):
            pixels.fill((0, 0, 128))
            pixels.show()
            time.sleep(0.0125)
            pixels.fill((0, 0, 0))
            pixels.show()
            time.sleep(0.0125)

    battery_voltage = get_voltage(vbat_voltage)
    print("VBat voltage: {:.2f}".format(battery_voltage))

    if (battery_voltage) >= 3.6:
        print("Battery volt > 3.6v --> battery good", "\n")
        # Set neopixel GREEN for 20s
        pixels.fill((0, 255, 0))
        pixels.show()
        time.sleep(5)
        # pixels[0] = (0, 255, 0)  # Green to show program started

    if ((battery_voltage) > 3.3 and (battery_voltage) < 3.6):
        print("Battery volt < 3.6v --> recharge soon", "\n")
        # Set neopixel ORANGE
        pixels.fill((255, 165, 0))
        pixels.show()
        time.sleep(5)

    if (battery_voltage) <= 3.3:
        print("Battery volt < 3.3v --> CRITICAL RECHARGE NEEDED", "\n")
        # Set neopixel RED
        pixels.fill((255, 0, 0))
        pixels.show()
        time.sleep(5)

    # Deep sleep - this will reduce power consumption significantly
    # print("Entering deep sleep mode...")
    # microcontroller.sleep()

    print("Stopping at end of program, code v. 23-April-2025")
    # sys.exit()

# Add this at the very bottom of the file:
if __name__ == "__main__":

    from code import uart_service  # Ensure `uart_service` is imported from `code.py`
    run_vcr(uart_service)  # Now correctly passing `uart_service`
