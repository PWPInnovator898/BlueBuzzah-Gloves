# This file is part of the BlueBuzzah Gloves project
# Copyright (c) 2025 BlueBuzzah Partners
# Licensed under the MIT License
#
# This file makes use of libraries and modules developed by Adafruit Industries,
# which are licensed separately under the MIT License and available at:
# https://github.com/adafruit/Adafruit_CircuitPython_Bundle
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
#
# For full licensing and attribution details, see LICENSES/MIT.txt and ATTRIBUTION.md

import defaults
import auth_token
import time
import analogio
import board
import neopixel
import adafruit_ble
import supervisor
import storage
from adafruit_ble.services.nordic import UARTService
from adafruit_ble.advertising.standard import ProvideServicesAdvertisement

pixel = neopixel.NeoPixel(board.NEOPIXEL, 1, brightness=0.2)
pixel.fill((0, 0, 0))

EXPECTED_TOKEN = "bluebuzzah-secure-v1"

if auth_token.AUTH_TOKEN != EXPECTED_TOKEN:
    print("🚫 Unauthorized device — halting.")
    time.sleep(1.0)
    while True:
        pixel.fill((255, 0, 0))  # Red ON
        time.sleep(0.25)
        pixel.fill((0, 0, 0))  # OFF
        time.sleep(0.25)

ble = adafruit_ble.BLERadio()
ble.name = "VL"  # Master board BLE name
uart_service = UARTService()
advertisement = ProvideServicesAdvertisement(uart_service)
advertisement.complete_name = ble.name
DEVICE_ROLE = "MASTER"
CHUNK_SIZE = 100

# Assign role tag for clarity
if ble.name == "VL":
    ROLE_TAG = "[VL]"
elif ble.name == "VR":
    ROLE_TAG = "[VR]"
else:
    ROLE_TAG = "[??]"


def blink_neopixel(color, blinks, delay):
    for _ in range(blinks):
        pixel.fill(color)
        time.sleep(delay)
        pixel.fill((0, 0, 0))
        time.sleep(delay)


def pulse_purple(duration_sec):
    end = time.monotonic() + duration_sec
    while time.monotonic() < end:
        for i in range(0, 256, 10):
            pixel.fill((i // 2, 0, i))
            time.sleep(0.01)
        for i in range(255, -1, -10):
            pixel.fill((i // 2, 0, i))
            time.sleep(0.01)
    pixel.fill((0, 0, 0))


def check_glove_status():
    try:
        vbat_voltage = analogio.AnalogIn(board.VOLTAGE_MONITOR)
        battery_voltage = (vbat_voltage.value * 3.3) / 65536 * 2
        vbat_voltage.deinit()

        time.sleep(0.2)

        message = "Bat: {:.2f}V\n".format(battery_voltage)
        uart_service.write(message.encode())
        time.sleep(0.05)
        uart_service.write("Done checking gloves.\n".encode())
        time.sleep(0.05)

        if battery_voltage > 3.7:
            color = (0, 255, 0)  # Green (Good)
        elif battery_voltage > 3.4:
            color = (255, 150, 0)  # Yellow (Medium)
        else:
            color = (255, 0, 0)  # Red (Low)

        blink_neopixel(color, 2, 0.5)
        time.sleep(0.1)

    except Exception as e:
        print("[ERROR] Could not check gloves:", e)
        try:
            uart_service.write("[ERROR] Failed to check gloves.\n".encode())
            time.sleep(0.05)
        except Exception as ble_error:
            print("[ERROR] BLE UART write failed:", ble_error)


def start_ble_advertising():
    ble.stop_advertising()
    time.sleep(0.5)
    if not ble.connected:
        print(f"Advertising as '{ble.name}'...")
        ble.start_advertising(advertisement, interval=0.1)

def stop_ble():
    print("Stopping BLE...")
    ble.stop_advertising()
    for conn in ble.connections:
        conn.disconnect()
    time.sleep(0.2)

def en_rw_filesystem():
    if supervisor.runtime.usb_connected:
        print("USB connected. Filesystem stays READ-ONLY.")
    else:
        print("Enabling RW mode for FileGlider...")
        storage.remount("/", readonly=False)

def start_vcr_program():
    print("[SYSTEM] Launching VCR session...")
    supervisor.set_next_code_file("code_master.py")
    supervisor.reload()

def send_defaults_file():
    print(f"{ROLE_TAG} Sending defaults.py to Slave...")
    try:
        with open("/defaults.py", "r") as f:
            content = f.read()
        uart_service.write("SEND_DEFAULTS_BEGIN\n".encode())
        time.sleep(0.05)
        for i in range(0, len(content), CHUNK_SIZE):
            uart_service.write(content[i : i + CHUNK_SIZE].encode())
            time.sleep(0.05)
        uart_service.write("SEND_DEFAULTS_END\n".encode())
        time.sleep(0.05)
        print(f"{ROLE_TAG} defaults.py sent!")
        blink_neopixel((0, 255, 255), 3, 0.25)
    except Exception as e:
        print("Error:", e)
        blink_neopixel((255, 0, 0), 3, 0.25)

def view_defaults_file():
    try:
        uart_service.write(f"{ROLE_TAG}[INFO] Viewing Defaults File...".encode())
        time.sleep(0.05)
        uart_service.write("\n=== START OF DEFAULTS.PY ===".encode())
        time.sleep(0.05)
        with open("/defaults.py", "r") as f:
            line_number = 1
            for line in f:
                formatted_line = "[{:02d}] {}".format(line_number, line)
                uart_service.write(formatted_line.encode())
                time.sleep(0.05)
                line_number += 1
        uart_service.write("=== END OF DEFAULTS.PY ===\n".encode())
        time.sleep(0.05)
        uart_service.write("\n Done displaying defaults.py. Next command?".encode())
        time.sleep(0.05)
    except Exception as e:
        print("[ERROR] Could not send defaults file:", e)
        uart_service.write("[ERROR] Unable to read defaults.py".encode())
        time.sleep(0.05)


# Begin BLE advertising
start_ble_advertising()
print("BLE advertising started for VL...")

startup_time = time.monotonic()
command_received = False

# Startup 12-second (default) window
while time.monotonic() - startup_time < defaults.STARTUP_WINDOW:
    pulse_purple(1)
    if ble.connected and uart_service.in_waiting:
        raw_msg = uart_service.readline()
        if raw_msg is not None:
            msg = raw_msg.strip().decode()
            if not msg:
                continue
            msg = msg[0]

            if msg not in ["f", "c", "g", "v", "r", "x", "1", "2", "3", "4"]:
                print(f"[WARNING] Unknown input ignored: '{msg}'")
                continue

            print(f"Received: '{msg}'")

            if msg == "f":
                uart_service.write(
                    f"{ROLE_TAG}[INFO] FileGlider Mode Enabled. \
                                    Open FileGlider app".encode()
                )
                time.sleep(0.05)
                en_rw_filesystem()
                blink_neopixel((255, 255, 255), 5, 0.5)
                command_received = True
                break

            elif msg == "c":
                uart_service.write(f"{ROLE_TAG}[INFO] Calibration Start\n".encode())
                time.sleep(0.05)
                blink_neopixel((255, 255, 0), 5, 0.25)
                command_received = True
                break

            elif msg == "g":
                uart_service.write(f"{ROLE_TAG}[INFO] Battery Check Start\n".encode())
                time.sleep(0.05)
                check_glove_status()
                command_received = True
                break

            elif msg == "v":
                uart_service.write(f"{ROLE_TAG}[INFO] Viewing Defaults".encode())
                time.sleep(0.05)
                view_defaults_file()
                command_received = True
                break

            elif msg == "r":
                uart_service.write(
                    f"{ROLE_TAG}[INFO] \
                                    Restarting to Menu Controller".encode()
                )
                time.sleep(0.05)
                blink_neopixel((0, 255, 0), 5, 0.25)
                print("[SYSTEM] Rebooting into BLE Menu Mode")
                time.sleep(0.5)
                supervisor.set_next_code_file("menu_controller.py")
                supervisor.reload()

            elif msg == "x":
                uart_service.write(
                    f"{ROLE_TAG}[INFO] \
                                    Sending Defaults File to Slave...".encode()
                )
                time.sleep(0.05)
                send_defaults_file()
                command_received = True
                break

            elif msg == "4":
                uart_service.write(
                    f"{ROLE_TAG}[INFO] \
                                    Selecting Custom VCR settings ...".encode()
                )
                time.sleep(0.05)
                try:
                    storage.remount("/", readonly=False)
                    with open("defaults_CustomVCR.py", "r") as src:
                        with open("defaults.py", "w") as dst:
                            dst.write(src.read())
                    print("Loaded Custom VCR settings. Remember to upload to VR...\n")
                    # send_defaults_file()  # Send to VR
                    time.sleep(2)
                    # supervisor.reload()
                except Exception as e:
                    print("Failed to load CustomVCR defaults:", e)
                command_received = True
                break

            elif msg == "3":
                uart_service.write(
                    f"{ROLE_TAG}[INFO] \
                                    Selecting Hybrid VCR settings ...".encode()
                )
                time.sleep(0.05)
                try:
                    storage.remount("/", readonly=False)
                    with open("defaults_HybridVCR.py", "r") as src:
                        with open("defaults.py", "w") as dst:
                            dst.write(src.read())
                    print("Loaded HybridVCR settings. Remember to upload to VR...\n")
                    # send_defaults_file()  # Send to VR
                    time.sleep(2)
                    # supervisor.reload()
                except Exception as e:
                    print("Failed to load HybridVCR defaults:", e)
                command_received = True
                break

            elif msg == "2":
                uart_service.write(
                    f"{ROLE_TAG}[INFO] \
                                    Selecting Noisy VCR settings ...".encode()
                )
                time.sleep(0.05)
                try:
                    storage.remount("/", readonly=False)
                    with open("defaults_NoisyVCR.py", "r") as src:
                        with open("defaults.py", "w") as dst:
                            dst.write(src.read())
                    print("Loaded NoisyVCR settings. Remember to upload to VR...\n")
                    # send_defaults_file()  # Send to VR
                    time.sleep(2)
                    # supervisor.reload()
                except Exception as e:
                    print("Failed to load NoisyVCR defaults:", e)
                command_received = True
                break

            elif msg == "1":
                uart_service.write(
                    f"{ROLE_TAG}[INFO] \
                                    Selecting Regular VCR settings ...".encode()
                )
                time.sleep(0.05)
                try:
                    storage.remount("/", readonly=False)
                    with open("defaults_RegVCR.py", "r") as src:
                        with open("defaults.py", "w") as dst:
                            dst.write(src.read())
                    print("Loaded Regular VCR settings. Remember to upload to VR...\n")
                    # send_defaults_file()  # Send to VR
                    time.sleep(2)
                    # supervisor.reload()
                except Exception as e:
                    print("Failed to load RegVCR defaults:", e)
                command_received = True
                break

if not command_received:
    print("No BLE command. Starting therapy...")
    stop_ble()
    start_vcr_program()

# Remain in utility mode after startup
while True:
    pixel.fill((64, 0, 128))
    time.sleep(0.5)
    if ble.connected and uart_service.in_waiting:
        raw_msg = uart_service.readline()
        if raw_msg is not None:
            msg = raw_msg.strip().decode()
            if not msg:
                continue
            msg = msg[0]

            if msg not in ["f", "c", "g", "v", "r", "x", "1", "2", "3", "4"]:
                print(f"[WARNING] Unknown input ignored: '{msg}'")
                continue

            print(f"Received: '{msg}'")

            if msg == "f":
                uart_service.write(
                    f"{ROLE_TAG}[INFO] FileGlider \
                                    Mode Enabled. Open FileGlider app".encode()
                )
                time.sleep(0.05)
                en_rw_filesystem()
                blink_neopixel((255, 255, 255), 5, 0.5)

            elif msg == "c":
                uart_service.write(f"{ROLE_TAG}[INFO] Calibration Start\n".encode())
                time.sleep(0.05)
                blink_neopixel((255, 255, 0), 5, 0.25)

            elif msg == "g":
                uart_service.write(f"{ROLE_TAG}[INFO] Battery Check Start\n".encode())
                time.sleep(0.05)
                check_glove_status()

            elif msg == "v":
                uart_service.write(f"{ROLE_TAG}[INFO] Viewing Defaults".encode())
                time.sleep(0.05)
                view_defaults_file()

            elif msg == "r":
                uart_service.write(
                    f"{ROLE_TAG}[INFO] \
                                    Restarting to Menu Controller".encode()
                )
                time.sleep(0.05)
                blink_neopixel((255, 0, 0), 5, 0.25)
                print("[SYSTEM] Rebooting into BLE Menu Mode...")
                time.sleep(0.5)
                supervisor.set_next_code_file("menu_controller.py")
                supervisor.reload()

            elif msg == "x":
                uart_service.write(
                    f"{ROLE_TAG}[INFO] Sending \
                                    Defaults File to Slave".encode()
                )
                time.sleep(0.05)
                blink_neopixel((255, 255, 255), 5, 0.25)
                print("[SYSTEM] Sending Defaults to Right Glove...")
                time.sleep(0.5)
                send_defaults_file()

            elif msg == "4":
                uart_service.write(f"{ROLE_TAG} Using Custom VCR defaults..\n".encode())
                time.sleep(0.05)
                try:
                    storage.remount("/", readonly=False)
                    with open("defaults_CustomVCR.py", "r") as src:
                        with open("defaults.py", "w") as dst:
                            dst.write(src.read())
                    # send_defaults_file()
                    blink_neopixel((0, 255, 255), 5, 0.2)
                    print("[SYSTEM] CustomVCR applied. Remember to upload to VR.")
                except Exception as e:
                    print("Failed to apply CustomVCR:", e)

            elif msg == "3":
                uart_service.write(f"{ROLE_TAG} Using Hybrid VCR defaults..\n".encode())
                time.sleep(0.05)
                try:
                    storage.remount("/", readonly=False)
                    with open("defaults_HybridVCR.py", "r") as src:
                        with open("defaults.py", "w") as dst:
                            dst.write(src.read())
                    # send_defaults_file()
                    blink_neopixel((0, 255, 255), 5, 0.2)
                    print("[SYSTEM] HybridVCR def. applied. Remember to upload to VR.")
                except Exception as e:
                    print("Failed to apply HybridVCR:", e)

            elif msg == "2":
                uart_service.write(f"{ROLE_TAG} Using NoisyVCR defaults...\n".encode())
                time.sleep(0.05)
                try:
                    storage.remount("/", readonly=False)
                    with open("defaults_NoisyVCR.py", "r") as src:
                        with open("defaults.py", "w") as dst:
                            dst.write(src.read())
                    # send_defaults_file()
                    blink_neopixel((0, 255, 255), 5, 0.2)
                    print("[SYSTEM] NoisyVCR def. applied. Remember to upload to VR.")
                except Exception as e:
                    print("Failed to apply NoisyVCR:", e)

            elif msg == "1":
                uart_service.write(f"{ROLE_TAG} Using RegVCR defaults...\n".encode())
                time.sleep(0.05)
                try:
                    storage.remount("/", readonly=False)
                    with open("defaults_RegVCR.py", "r") as src:
                        with open("defaults.py", "w") as dst:
                            dst.write(src.read())
                    # send_defaults_file()
                    blink_neopixel((0, 255, 255), 5, 0.2)
                    print("[SYSTEM] RegVCR def. applied. Remember to upload to VR.")
                except Exception as e:
                    print("Failed to apply RegVCR:", e)

    time.sleep(0.2)
