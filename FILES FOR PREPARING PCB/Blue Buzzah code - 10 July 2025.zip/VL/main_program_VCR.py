# This file is part of the BlueBuzzah Gloves project
# Copyright (c) 2025 BlueBuzzah Partners
# Licensed under the MIT License
#
# This file makes use of libraries and modules developed by Adafruit Industries,
# which are licensed separately under the MIT License and available at:
# https://github.com/adafruit/Adafruit_CircuitPython_Bundle, and the Buzzah project at:
# https://github.com/kriswilk/buzzah
# For licensing and attribution details, see LICENSES/MIT.txt and ATTRIBUTION.md at:
# https://github.com/PWPInnovator898/BlueBuzzah-Gloves
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

def run_vcr(uart_service):
    print("Running main BUZZ program...")

    # ******************** MASTER *************************
    # Get free-run mode default VCR settings
    import defaults

    import board
    import gc
    # from adafruit_ble.services.standard import CurrentTimeService
    # from adafruit_ble import BLERadio
    # from adafruit_ble.advertising.standard import ProvideServicesAdvertisement
    # from adafruit_ble.services.nordic import UARTService

    import adafruit_itertools
    from adafruit_itertools import permutations
    import adafruit_drv2605
    import adafruit_tca9548a
    # import microcontroller

    import random
    import time
    from analogio import AnalogIn
    from neopixel_manager import pixels

    # import sys

    # import storage
    # import adafruit_ble
    # from adafruit_ble.services.standard import CurrentTimeService
    # from adafruit_ble.advertising.standard import SolicitServicesAdvertisement
    # import supervisor

    # Set up to monitor battery voltage
    vbat_voltage = AnalogIn(board.VOLTAGE_MONITOR)

    def get_voltage(pin):
        return (pin.value * 3.3) / 65536 * 2

    # Show battery status before therapy
    battery_voltage = get_voltage(vbat_voltage)
    print("VBat voltage: {:.2f}".format(battery_voltage))

    if (battery_voltage) >= 3.6:
        print("Battery volt > 3.6v --> battery good", "\n")
        # Set neopixel GREEN for 3s
        pixels.fill((0, 255, 0))
        pixels.show()
        time.sleep(5)

    if ((battery_voltage) > 3.3 and (battery_voltage) < 3.6):
        print("Battery volt < 3.6v --> recharge soon", "\n")
        # Set neopixel ORANGE
        pixels.fill((255, 165, 0))
        pixels.show()
        time.sleep(5)

    if (battery_voltage) <= 3.3:
        print("Battery volt < 3.3v --> CRITICAL RECHARGE NEEDED", "\n")
        # Set neopixel RED
        pixels.fill((255, 0, 0))
        pixels.show()
        time.sleep(10)

    CUSTOMIZATIONS = True

    # Stop_LED = input("LEDs ok?")

    """
    ACTUATOR SPECIFICATIONS: These MUST be set to match the specifications of the
    actuator that you are using.
    """

    if CUSTOMIZATIONS:
        print(defaults.ACTUATOR_TYPE)
        print(defaults.ACTUATOR_VOLTAGE)
        print(defaults.ACTUATOR_FREQUENCY)
        print(defaults.RANDOM_FREQ)
        print(defaults.ACTUATOR_FREQL)
        print(defaults.ACTUATOR_FREQNOM)
        print(defaults.ACTUATOR_FREQH)

        # COORDINATED RESET PARAMETERS: These are based on the published research

        # Vibration amplitude range, in %
        print(defaults.AMPLITUDE_MIN)
        print(defaults.AMPLITUDE_MAX)

        # Duration of each vibration and subsequent pause, each in seconds
        print(defaults.TIME_ON)
        print(defaults.TIME_OFF)

        # Duration of the relaxation period between sets of vibrations, in seconds
        print(defaults.TIME_RELAX)

        # Jitter, in %
        print(defaults.JITTER)

        # Mirror left / right hand vibration patterns
        print(defaults.MIRROR)

        # Duration of the therapy session, in minutes
        print(defaults.TIME_SESSION)

        # Check all values - comment out later
        # CHECKT = input("pause?")

    PATTERNS_LEFT = list(adafruit_itertools.permutations(range(0, 4)))
    # PATTERNS_RIGHT = list(adafruit_itertools.permutations(range(0, 4)))
    # print(PATTERNS_LEFT)
    # print(PATTERNS_RIGHT)
    # CHECKT = input("patterns?")

    L_RNDP = list(permutations(range(0, 4)))     # 24 patterns for LEFT
    R_RNDP = list(permutations(range(4, 8)))     # 24 patterns for RIGHT

    # Apply shared seed only when jitter setting is not zero
    SHARED_SEED = 123456  # Default seed if jitter is off
    if defaults.JITTER != 0:
        SHARED_SEED = int(time.monotonic() * 1000) % 1000000
        print("[VL] Shared seed from time monotonic:", SHARED_SEED)
        random.seed(SHARED_SEED)  # Syncs jitter + pattern randomization
        uart_service.write("SEED:{}\n".format(SHARED_SEED))  # ← send seed to VR
        time.sleep(0.05)  # small delay to ensure stable BLE transmission

    def random_sequence():
        if defaults.MIRROR:
            pattern_left = random.choice(PATTERNS_LEFT)
            pattern_right = pattern_left
        else:
            pattern_left = random.choice(
                list(adafruit_itertools.permutations(range(0, 4))))
            pattern_right = random.choice(R_RNDP)
        return zip(pattern_left, pattern_right)

    def rndp_sequence():
        pattern_left_rndp = random.choice(L_RNDP)
        if defaults.MIRROR:
            pattern_right_rndp = [x - 4 for x in pattern_left_rndp]
        else:
            pattern_right_rndp = random.choice(R_RNDP)
        return zip(pattern_left_rndp, pattern_right_rndp)

    def fingers_on(fingers):
        for finger in fingers:
            actual_finger = finger[0] if isinstance(finger, tuple) else finger
            if 0 <= actual_finger < len(drivers) and drivers[actual_finger]:
                drivers[actual_finger].realtime_value = random.randint(
                    defaults.AMPLITUDE_MIN, defaults.AMPLITUDE_MAX
                )

    def fingers_off(fingers):
        for finger in fingers:
            actual_finger = finger[0] if isinstance(finger, tuple) else finger
            if 0 <= actual_finger < len(drivers) and drivers[actual_finger]:
                drivers[actual_finger].realtime_value = 0

    def buzz_sequence(sequence):
        for fingers in sequence:
            fingers_on(fingers)
            time.sleep(defaults.TIME_ON)
            fingers_off(fingers)
            time.sleep(
                defaults.TIME_OFF
                + random.uniform(-defaults.TIME_JITTER, defaults.TIME_JITTER)
            )

    # Start of main program flow
    # BLE radio setup
    # ble = BLERadio()
    # uart_service = UARTService()
    # advertisement = ProvideServicesAdvertisement(uart_service)

    # Advertise when not connected
    # ble.start_advertising(advertisement)

    start_config_time = time.time()  # keep track of time in setup
    # print(start_config_time)

    # Flash neopixel blue at begin of buzz cycles in main while loop
    for i in range(5):
        pixels.fill((0, 0, 255))
        pixels.show()
        time.sleep(0.05)
        pixels.fill((0, 0, 0))
        pixels.show()
        time.sleep(0.05)

    # new stop
    # ble.stop_advertising

    print("VCR starting up... wait 1s 'til power supply is stable ...")

    # set up i2c from nRF52840 to i2c mux to to haptic drivers
    i2c = board.I2C()
    mux = adafruit_tca9548a.PCA9546A(i2c)

    # Scan for I2C addresses... and unlock master I2C bus
    while not i2c.try_lock():
        pass
    try:
        print(
            "I2C Master I2C addresses found:",
            [hex(device_address) for device_address in i2c.scan()],
        )
        time.sleep(0.1)
    finally:
        i2c.unlock()

    # Scan for slave I2C addresses... and unlock each slave I2C bus
    for channel in range(4):
        if mux[channel].try_lock():
            print("Slave i2c Channel {}:".format(channel), end="")
            addresses = mux[channel].scan()
            print([hex(address) for address in addresses])
            mux[channel].unlock()

    print("Begin haptic driver config ...", "\n")

    # print("\nBEGIN initial config driver loop")

    drivers = []
    for port in mux:
        # print("APPEND a haptic driver to each i2c port", port)
        try:
            drivers.append(adafruit_drv2605.DRV2605(port))
        except ValueError:
            drivers.append(False)

    # print("BEGIN setting haptic driver config registers")
    for driver in drivers:
        # print(driver)
        if driver:
            # set actuator type
            if defaults.ACTUATOR_TYPE == "LRA":
                driver.use_LRM()
                # print("set LRA mode")
            else:
                driver.use_ERM()

            # set open-loop mode (both ERM & LRA)
            # print("set open-loop mode")
            control3 = driver._read_u8(0x1D)
            driver._write_u8(0x1D, control3 | 0x21)

            # set peak voltage
            # print("set peak voltage")
            driver._write_u8(0x17, int(defaults.ACTUATOR_VOLTAGE / 0.02122))

            # set driving frequency
            # print("set driving frequency")
            driver._write_u8(0x20, int(1 / (defaults.ACTUATOR_FREQUENCY * 0.00009849)))
            # print("main", defaults.ACTUATOR_FREQUENCY)

            # set initial output amplitude and activate RTP mode
            driver.realtime_value = 0
            # print("activate RTP mode")
            driver.mode = adafruit_drv2605.MODE_REALTIME
            # print(drivers)

    # vbat_counter = 0  # optional battery monitor loop counter to flash every # cycles
    buzz_cycle_count = 0  # buzz cycle counter

    end_config_time = time.time()
    elapsed_config_time = end_config_time - start_config_time
    # print("config_time = ", elapsed_config_time)
    # input("pause to show config time (seconds) \n")
    # sync_start = input("Begin sync")

    # main loop
    while time.time() < defaults.TIME_END + elapsed_config_time:
        if defaults.RANDOM_FREQ:
            drivers = []
            for port in mux:
                try:
                    drivers.append(adafruit_drv2605.DRV2605(port))
                except ValueError:
                    drivers.append(False)

            for driver in drivers:
                if driver:
                    # set actuator type
                    if defaults.ACTUATOR_TYPE == "LRA":
                        driver.use_LRM()
                    else:
                        driver.use_ERM()

                    # set open-loop mode (both ERM & LRA)
                    control3 = driver._read_u8(0x1D)
                    driver._write_u8(0x1D, control3 | 0x21)

                    # set peak voltage
                    driver._write_u8(0x17, int(defaults.ACTUATOR_VOLTAGE / 0.02122))

                    # set driving frequency
                    # FREQ_OPTION = (
                    # defaults.ACTUATOR_FREQL,
                    # defaults.ACTUATOR_FREQNOM,
                    # defaults.ACTUATOR_FREQH,
                    # )
                    ACTUATOR_FREQUENCY = random.randrange(
                        defaults.ACTUATOR_FREQL, defaults.ACTUATOR_FREQH, 5)
                    driver._write_u8(0x20, int(1 / (ACTUATOR_FREQUENCY * 0.00009849)))
                    # print("innerloop", ACTUATOR_FREQUENCY)

                    # set initial output amplitude and activate RTP mode
                    driver.realtime_value = 0
                    driver.mode = adafruit_drv2605.MODE_REALTIME
                    # print(driver)

        buzz_cycle_count += 1
        # print(f"Buzz cycle count: {buzz_cycle_count}")

        if buzz_cycle_count == 1:  # indicate start INITIAL buzz cycle w/ white led
            print("Starting **FIRST** buzz macrocycle w/ white LED ...")
            pixels.fill((255, 255, 255))
            pixels.show()
            time.sleep(0.1)
            pixels.fill((0, 0, 0))
            pixels.show()

        # macrocell_start = int(time.monotonic() * 1000)
        # print("[VL] Buzz Macrocycle Start @", macrocell_start)

        # Execute a Periodic Sync Every Macrocycle
        if buzz_cycle_count % 1 == 0 and uart_service:  # Adjust '1' as needed
            sync_adj_timestamp = int(time.monotonic() * 1000)
            # print(f"[VL] Sending SYNC_ADJ @ {sync_adj_timestamp}")

            # Send SYNC_ADJ message
            uart_service.write(f"SYNC_ADJ:{sync_adj_timestamp}\n")
            # print(f"[VL] SYNC_ADJ Sent: {sync_adj_timestamp} ms")

            # Wait for ACK from Slave (with timeout)
            ack_received = False
            start_wait = time.monotonic()
            while not ack_received:
                if uart_service.in_waiting:
                    response = uart_service.readline().decode().strip()
                    if response == "ACK_SYNC_ADJ":
                        ack_received = True
                        ack_timestamp = int(time.monotonic() * 1000)
                        print(f"[VL] SYNC_ADJ ACK received! \
                              (Delay: {ack_timestamp - sync_adj_timestamp} ms)")
                if time.monotonic() - start_wait > 2:  # Timeout after 2 sec
                    print("[VL] SYNC_ADJ ACK Timeout! Proceeding anyway.")
                    break

            # Send SYNC_ADJ_START signal to Slave
            time.sleep(0.01)  # Small delay to avoid congestion
            sync_adj_start_timestamp = int(time.monotonic() * 1000)
            print(f"[VL] SYNC_ADJ_START to Slave @ {sync_adj_start_timestamp}")
            uart_service.write("SYNC_ADJ_START\n")
            # print(f"[VL] SYNC_ADJ_START Sent: {sync_adj_start_timestamp} ms")

        # Proceed with next cycle

        # Compensate for Slave's longer I2C/NeoPixel setup before buzz
        time.sleep(0.02)  # 20 ms execution balancing delay

        if defaults.PATTERN_TYPE == "RNDP":
            buzz_sequence(rndp_sequence())
            buzz_sequence(rndp_sequence())
            buzz_sequence(rndp_sequence())
            time.sleep(defaults.TIME_RELAX)
            time.sleep(defaults.TIME_RELAX)
        else:
            buzz_sequence(random_sequence())
            buzz_sequence(random_sequence())
            buzz_sequence(random_sequence())
            time.sleep(defaults.TIME_RELAX)
            time.sleep(defaults.TIME_RELAX)

        gc.collect()
        # Optional: debug free memory
        # print("[VR] Free RAM:", gc.mem_free())

        # macrocell_end = int(time.monotonic() * 1000)
        # print("[VL] Buzz macrocycle END @", macrocell_end)
        # print("[VL] Buzz macrocycle duration=", macrocell_end - macrocell_start)
        # print("Completing 1 x Buzz Macrocycle in main_program_VCR...")

        # Optional SYNC_LED flash at end of buzz macrocycle

        if (defaults.SYNC_LED):
            pixels.fill((0, 0, 128))
            pixels.show()
            time.sleep(0.0125)
            pixels.fill((0, 0, 0))
            pixels.show()
            time.sleep(0.0125)

    battery_voltage = get_voltage(vbat_voltage)
    print("VBat voltage: {:.2f}".format(battery_voltage))

    if (battery_voltage) >= 3.6:
        print("Battery volt > 3.6v --> battery good", "\n")
        # Set neopixel GREEN for 20s
        pixels.fill((0, 255, 0))
        pixels.show()
        time.sleep(5)
        # pixels[0] = (0, 255, 0)  # Green to show program started

    if ((battery_voltage) > 3.3 and (battery_voltage) < 3.6):
        print("Battery volt < 3.6v --> recharge soon", "\n")
        # Set neopixel ORANGE
        pixels.fill((255, 165, 0))
        pixels.show()
        time.sleep(5)

    if (battery_voltage) <= 3.3:
        print("Battery volt < 3.3v --> CRITICAL RECHARGE NEEDED", "\n")
        # Set neopixel RED
        pixels.fill((255, 0, 0))
        pixels.show()
        time.sleep(5)

    # Deep sleep - this will reduce power consumption significantly
    # print("Entering deep sleep mode...")
    # microcontroller.sleep()

    print("Stopping at end of program, code v. 23-April-2025")
    # sys.exit()

# Add this at the very bottom of the file:
if __name__ == "__main__":

    from code import uart_service  # Ensure `uart_service` is imported from `code.py`
    run_vcr(uart_service)  # Now correctly passing `uart_service`
