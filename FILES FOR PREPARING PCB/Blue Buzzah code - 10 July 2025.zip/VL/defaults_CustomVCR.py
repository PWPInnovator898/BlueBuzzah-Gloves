# CUSTOM vCR settings: non-mirrored; jitter on; random freq; random amplitude
# Same as hybrid but adds randomized freq and amplitude
import time
ACTUATOR_TYPE = "LRA"
ACTUATOR_VOLTAGE = 2.50
ACTUATOR_FREQUENCY = 250
RANDOM_FREQ = True
ACTUATOR_FREQL = 210
ACTUATOR_FREQNOM = ACTUATOR_FREQUENCY
ACTUATOR_FREQH = 260
AMPLITUDE_MIN = 70
AMPLITUDE_MAX = 100
TIME_SESSION = 120
TIME_ON = 0.100
TIME_OFF = 0.067
TIME_RELAX = 4 * (TIME_ON + TIME_OFF)
JITTER = 23.5
TIME_JITTER = (TIME_ON + TIME_OFF) * (JITTER / 100) / 2
TIME_END = time.time() + 60 * TIME_SESSION
PATTERN_TYPE = "RNDP" # keep this setting as "RNDP"
MIRROR = False
SYNC_LED = True
STARTUP_WINDOW = 6
# ---------------------
