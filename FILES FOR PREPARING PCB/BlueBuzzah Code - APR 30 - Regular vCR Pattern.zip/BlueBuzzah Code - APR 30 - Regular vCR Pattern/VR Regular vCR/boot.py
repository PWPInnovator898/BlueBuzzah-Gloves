import board
import time
import adafruit_drv2605
import adafruit_tca9548a
import supervisor

# Early LRA reset
i2c = board.I2C()
mux = adafruit_tca9548a.PCA9546A(i2c)

for port in mux:
    try:
        drv = adafruit_drv2605.DRV2605(port)
        drv.realtime_value = 0  # Cut off signal
        drv.mode = 0x00  # Return to internal default (standby)
        time.sleep(0.01)
    except ValueError:
        pass

# Ensure code.py is the file that runs on boot.
supervisor.set_next_code_file("menu_controller.py")
supervisor.reload()
