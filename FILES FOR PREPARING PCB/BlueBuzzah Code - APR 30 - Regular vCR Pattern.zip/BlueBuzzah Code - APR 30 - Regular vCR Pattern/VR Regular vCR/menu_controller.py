import time
import board
import neopixel
import adafruit_ble
import supervisor
import storage
import analogio
from adafruit_ble.services.nordic import UARTService
from adafruit_ble.advertising.standard import ProvideServicesAdvertisement

pixel = neopixel.NeoPixel(board.NEOPIXEL, 1, brightness=0.2)
pixel.fill((0, 0, 0))

ble = adafruit_ble.BLERadio()
ble.name = "VR"  # Slave board BLE name
uart_service = UARTService()
advertisement = ProvideServicesAdvertisement(uart_service)
advertisement.complete_name = ble.name
DEVICE_ROLE = "SLAVE"
CHUNK_SIZE = 100

# Assign role tag for clarity
if ble.name == "VL":
    ROLE_TAG = "[VL]"
elif ble.name == "VR":
    ROLE_TAG = "[VR]"
else:
    ROLE_TAG = "[??]"

def blink_neopixel(color, blinks, delay):
    for _ in range(blinks):
        pixel.fill(color)
        time.sleep(delay)
        pixel.fill((0, 0, 0))
        time.sleep(delay)

def pulse_purple(duration_sec):
    end = time.monotonic() + duration_sec
    while time.monotonic() < end:
        for i in range(0, 256, 10):
            pixel.fill((i // 2, 0, i))
            time.sleep(0.01)
        for i in range(255, -1, -10):
            pixel.fill((i // 2, 0, i))
            time.sleep(0.01)
    pixel.fill((0, 0, 0))

def start_ble_advertising():
    ble.stop_advertising()
    time.sleep(0.5)
    if not ble.connected:
        print(f"Advertising as '{ble.name}'...")
        ble.start_advertising(advertisement, interval=0.1)

def stop_ble():
    print("Stopping BLE...")
    ble.stop_advertising()
    for conn in ble.connections:
        conn.disconnect()
    time.sleep(0.2)

def en_rw_filesystem():
    if supervisor.runtime.usb_connected:
        print("USB connected. Filesystem stays READ-ONLY.")
    else:
        print("Enabling RW mode for FileGlider...")
        storage.remount("/", readonly=False)

def start_vcr_program():
    print("[SYSTEM] Launching VCR session...")
    supervisor.set_next_code_file("code_slave.py")
    supervisor.reload()

def check_glove_status():
    try:
        vbat_voltage = analogio.AnalogIn(board.VOLTAGE_MONITOR)
        battery_voltage = (vbat_voltage.value * 3.3) / 65536 * 2
        vbat_voltage.deinit()

        time.sleep(0.2)

        message = "Bat: {:.2f}V\n".format(battery_voltage)
        uart_service.write(message.encode())
        time.sleep(0.05)
        uart_service.write("Done checking gloves.\n".encode())
        time.sleep(0.05)

        if battery_voltage > 3.7:
            color = (0, 255, 0)  # Green
        elif battery_voltage > 3.4:
            color = (255, 150, 0)  # Yellow
        else:
            color = (255, 0, 0)  # Red

        blink_neopixel(color, 2, 0.5)
        time.sleep(0.1)

    except Exception as e:
        print("[ERROR] Could not check gloves:", e)
        try:
            uart_service.write("[ERROR] Failed to check gloves.\n".encode())
            time.sleep(0.05)
        except Exception as ble_error:
            print("[ERROR] BLE UART write failed:", ble_error)

def view_defaults_file():
    try:
        uart_service.write(f"{ROLE_TAG}[INFO] Viewing Defaults File...\n".encode())
        time.sleep(0.05)
        uart_service.write("\n=== START OF DEFAULTS.PY ===\n".encode())
        time.sleep(0.05)
        with open("/defaults.py", "r") as f:
            line_number = 1
            for line in f:
                formatted_line = "[{:02d}] {}".format(line_number, line)
                uart_service.write(formatted_line.encode())
                time.sleep(0.05)
                line_number += 1
        uart_service.write("=== END OF DEFAULTS.PY ===\n".encode())
        time.sleep(0.05)
        uart_service.write("\n Done displaying defaults.py. Next command?\n".encode())
        time.sleep(0.05)
    except Exception as e:
        print("[ERROR] Could not send defaults file:", e)
        uart_service.write("[ERROR] Unable to read defaults.py\n".encode())
        time.sleep(0.05)

# Begin BLE advertising
start_ble_advertising()
print("BLE advertising started for VR...")

startup_time = time.monotonic()
command_received = False

# Startup 12-second window
while time.monotonic() - startup_time < 12:
    pulse_purple(1)
    if ble.connected and uart_service.in_waiting:
        raw_msg = uart_service.readline()
        if raw_msg is not None:
            msg = raw_msg.strip().decode()
            if not msg:
                continue
            msg = msg[0]

            if msg not in ['f', 'c', 'g', 'v', 'r', 'x']:
                print(f"[WARNING] Unknown input ignored: '{msg}'")
                continue

            print(f"Received: '{msg}'")

            if msg == "f":
                uart_service.write(f"{ROLE_TAG}[INFO] FileGlider Mode Enabled. \
                                    Open FileGlider app.\n".encode())
                time.sleep(0.05)
                en_rw_filesystem()
                blink_neopixel((255, 255, 255), 5, 0.5)
                command_received = True
                break

            elif msg == "c":
                uart_service.write(f"{ROLE_TAG}[INFO] Calibration Starting\n".encode())
                time.sleep(0.05)
                blink_neopixel((255, 255, 0), 5, 0.25)
                command_received = True
                break

            elif msg == "g":
                uart_service.write(f"{ROLE_TAG}[INFO] Battery Check Start\n".encode())
                time.sleep(0.05)
                check_glove_status()
                command_received = True
                break

            elif msg == "v":
                uart_service.write(f"{ROLE_TAG}[INFO] Viewing Defaults...\n".encode())
                time.sleep(0.05)
                view_defaults_file()
                command_received = True
                break

            elif msg == "r":
                uart_service.write(f"{ROLE_TAG}[INFO] Restarting \
                                    to Menu Controller...\n".encode())
                time.sleep(0.05)
                blink_neopixel((255, 0, 0), 5, 0.25)
                print("[SYSTEM] Rebooting into BLE Menu Mode...")
                time.sleep(0.5)
                supervisor.set_next_code_file("menu_controller.py")
                supervisor.reload()

            elif msg == "x":
                uart_service.write(f"{ROLE_TAG}[INFO] File Transfers \
                                    supported VL to VR only. Ignoring.\n".encode())
                time.sleep(0.05)
                command_received = True
                break

if not command_received:
    print("No BLE command. Starting therapy...")
    stop_ble()
    start_vcr_program()

# Infinite utility mode after startup
while True:
    if ble.connected and uart_service.in_waiting:
        raw_msg = uart_service.readline()
        if raw_msg is not None:
            msg = raw_msg.strip().decode()
            if not msg:
                continue
            msg = msg[0]

            if msg not in ['f', 'c', 'g', 'v', 'r', 'x']:
                print(f"[WARNING] Unknown input ignored: '{msg}'")
                continue

            print(f"Received: '{msg}'")

            if msg == "f":
                uart_service.write(f"{ROLE_TAG}[INFO] FileGlider \
                                    Mode Enabled. Open FileGlider app.\n".encode())
                time.sleep(0.05)
                en_rw_filesystem()
                blink_neopixel((255, 255, 255), 5, 0.5)

            elif msg == "c":
                uart_service.write(f"{ROLE_TAG}[INFO] Calibration Start\n".encode())
                time.sleep(0.05)
                blink_neopixel((255, 255, 0), 5, 0.25)

            elif msg == "g":
                uart_service.write(f"{ROLE_TAG}[INFO] Battery Check Start\n".encode())
                time.sleep(0.05)
                check_glove_status()

            elif msg == "v":
                uart_service.write(f"{ROLE_TAG}[INFO] Viewing Defaults...\n".encode())
                time.sleep(0.05)
                blink_neopixel((255, 255, 255), 5, 0.25)
                view_defaults_file()

            elif msg == "r":
                uart_service.write(f"{ROLE_TAG}[INFO] \
                                    Restarting to Menu Controller...\n".encode())
                time.sleep(0.05)
                blink_neopixel((255, 0, 0), 5, 0.25)
                print("[SYSTEM] Rebooting into BLE Menu Mode...")
                time.sleep(0.5)
                supervisor.set_next_code_file("menu_controller.py")
                supervisor.reload()

            elif msg == "x":
                uart_service.write(f"{ROLE_TAG}[INFO] File \
                                    Transfers support VL→VR only. Ignoring.\n".encode())
                time.sleep(0.05)

    time.sleep(0.2)
