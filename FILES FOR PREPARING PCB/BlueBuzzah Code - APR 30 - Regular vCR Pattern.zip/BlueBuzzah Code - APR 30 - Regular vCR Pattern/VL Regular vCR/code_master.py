import time
# import supervisor
from neopixel_manager import pixels
from adafruit_ble import BLERadio
from adafruit_ble.services.nordic import UARTService
from adafruit_ble.advertising.standard import ProvideServicesAdvertisement
from main_program_VCR import run_vcr

ble = BLERadio()
uart_service = UARTService()
advertisement = ProvideServicesAdvertisement(uart_service)
advertisement.complete_name = "VL"

def enter_low_power_mode():
    print("Entering lowest power mode...")
    pixels.fill((0, 0, 0))
    ble.stop_scan()
    ble.stop_advertising()
    # ble.disconnect()
    time.sleep(0.5)
    # supervisor.runtime.sleep_forever()

print("[VL] Setting up BLE advertisement with UARTService...")
ble.start_advertising(advertisement, interval=0.5)
print("[VL] Advertising as VL...")

start_time = time.monotonic()
slave_found = False

while time.monotonic() - start_time < 15:
    if ble.connected:
        print("[VL]Slave connected during 15s window!")
        connection = ble.connections[0]
        connection.interval = 0.0075
        connection.latency = 0
        connection.timeout = 0.1
        print("[VL] BLE parameters opt: Interval=7.5ms, Latency=0, Timeout=100ms")
        slave_found = True
        break

if not slave_found:
    print("[VL] No Slave found in 15s! Restart required.")
    pixels.fill((255, 0, 0))
    while True:
        pass

print("[VL] Slave connected! Waiting for READY signal...")

# NEW: Wait for Slave to send READY signal before sending SYNC
ready_received = False
start_wait = time.monotonic()

while time.monotonic() - start_wait < 8:
    message = uart_service.readline()
    if message:
        message = message.decode("utf-8").strip()
        print("[VL] Debug: Received: {}".format(message))
        if message == "READY":
            ready_received = True
            break

if not ready_received:
    print("[VL] No READY received! Restart required.")
    pixels.fill((255, 0, 0))
    while True:
        pass

# NEW: Retry sending SYNC until ACK is received
timestamp = int(time.monotonic() * 1000)
sync_message = "FIRST_SYNC:{}\n".format(timestamp)  # Mark first sync

ack_received = False
for attempt in range(3):
    print(f"[VL] Sending SYNC message (Attempt {attempt+1}): {sync_message}")
    sync_send_time = int(time.monotonic() * 1000)
    print(f"[VL] SYNC sent at {sync_send_time} ms")
    uart_service.write(sync_message.encode())
    time.sleep(0.5)

    message = uart_service.readline()
    if message:
        message = message.decode("utf-8").strip()
        print("[VL] Debug: Received: {}".format(message))
        if message == "ACK":
            ack_received = True
            break

if not ack_received:
    print("[VL] No ACK received! Restart required.")
    pixels.fill((255, 0, 0))
    while True:
        pass

print("[VL] Sending VCR_START...")
uart_service.write("VCR_START\n".encode())

print("[VL] Running main VCR program...")
run_vcr(uart_service)
enter_low_power_mode()
