# This file is part of the BlueBuzzah Gloves project
# Copyright (c) 2025 BlueBuzzah Partners
# Licensed under the MIT License
#
# This file makes use of libraries and modules developed by Adafruit Industries,
# which are licensed separately under the MIT License and available at:
# https://github.com/adafruit/Adafruit_CircuitPython_Bundle
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
#
# For full licensing and attribution details, see LICENSES/MIT.txt and ATTRIBUTION.md
# -----------------------------------------------------------------------------------

import time
# import supervisor
from neopixel_manager import pixels
from adafruit_ble import BLERadio
from adafruit_ble.services.nordic import UARTService
from main_program_VCR import run_vcr

ble = BLERadio()
uart_service = None
advertisement_name = "VR"

def enter_low_power_mode():
    print("Entering lowest power mode...")
    pixels.fill((0, 0, 0))
    ble.stop_scan()
    ble.stop_advertising()
    time.sleep(0.5)
    # supervisor.runtime.sleep_forever()

print("[VR] Setting up BLE scanning...")
for _ in range(3):
    pixels.fill((255, 255, 0))
    time.sleep(0.3)
    pixels.fill((0, 0, 0))
    time.sleep(0.3)

print("[VR] Scanning for VL...")
start_time = time.monotonic()
master_found = False

while time.monotonic() - start_time < 15:
    for adv in ble.start_scan(timeout=0.1, interval=0.0075, window=0.0075):
        if adv.complete_name == "VL":
            print("[VR] Found Master! Connecting...")
            connection = ble.connect(adv)
            time.sleep(0.2)
            if UARTService in connection:
                uart_service = connection[UARTService]
                master_found = True
            break
    if master_found:
        break

if not master_found:
    print("[VR] No Master found in 15s! Restart required.")
    pixels.fill((255, 0, 0))
    while True:
        pass

print("[VR] ✅ Connected to Master!")

# Send READY message to Master
print("[VR] Sending READY to Master...")
uart_service.write("READY\n".encode())

print("[VR] Searching for SYNC message...")
initial_time_offset = None  # Initialize offset variable

while True:
    message = uart_service.readline()
    if message:
        message = message.decode("utf-8").strip()
        print("[VR] Received: {}".format(message))

        if message.startswith("FIRST_SYNC:"):
            received_timestamp = int(message.split(":")[1])
            current_slave_time = int(time.monotonic() * 1000)

            # Apply fixed 20 ms compensation for BLE delay
            adjusted_sync_time = received_timestamp + 21
            applied_time_shift = adjusted_sync_time - current_slave_time
            initial_time_offset = current_slave_time + applied_time_shift

            print("[VR] First sync received. Adjusting timebase:")
            print("    Master (raw): {:>7} ms".format(received_timestamp))
            print("    Master (adj): {:>7} ms".format(adjusted_sync_time))
            print("    Slave Before: {:>10} ms".format(current_slave_time))
            print("    Applied Shift: {:>7} ms".format(applied_time_shift))
            print("    Slave After: {:>10} ms".format(initial_time_offset))

            uart_service.write("ACK\n".encode())
            time.sleep(0.1)
            break

        elif message.startswith("SYNC:"):
            received_timestamp = int(message.split(":")[1])

            if initial_time_offset is not None:
                adjusted_slave_time = received_timestamp + \
                    (int(time.monotonic() * 1000) - initial_time_offset)
                offset = adjusted_slave_time - received_timestamp

                print("[VR] Sync Adjustment Calculated:")
                print("    Master: {:>7} ms | Adjusted Slave: {:>10} ms".format(
                    received_timestamp, adjusted_slave_time))
                print("    Computed Offset: {:>7} ms".format(offset))

            else:
                offset = received_timestamp - int(time.monotonic() * 1000)
                print("[VR] SYNC received before FIRST_SYNC. "
                      "Computed Offset: {:>7} ms".format(offset))

            uart_service.write("ACK\n".encode())  # Send ACK
            time.sleep(0.1)
            break

print("[VR] SYNC received! Now listening for VCR_START...")

while True:
    message = uart_service.readline()
    if message:
        message = message.decode("utf-8").strip()
        print("[VR] Received: {}".format(message))

        if message == "VCR_START":
            print("[VR] Received VCR_START! Running...")
            run_vcr(uart_service)

    enter_low_power_mode()
    time.sleep(0.01)
    break
