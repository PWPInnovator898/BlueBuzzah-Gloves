import board
import neopixel

# Initialize NeoPixel LED
pixels = neopixel.NeoPixel(board.NEOPIXEL, 1, brightness=0.1)
